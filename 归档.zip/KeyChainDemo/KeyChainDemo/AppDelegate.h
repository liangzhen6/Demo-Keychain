//
//  AppDelegate.h
//  KeyChainDemo
//
//  Created by shenzhenshihua on 2017/5/9.
//  Copyright © 2017年 shenzhenshihua. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

